package com.qa.libraryTDD;

public class Library {
	
	public void checkOutItem() {
		
	}
	
	public void checkInItem() {
		
	}
	
	public void addItem() {
		
	}
	
	public void removeItem() {
		
	}
	
	public void updateItem() {
		
	}
	
	public void registerPerson() {
		
	}
	
	public void removePerson() {
		
	}
	
	public void updatePerson() {
		
	}
	
}
