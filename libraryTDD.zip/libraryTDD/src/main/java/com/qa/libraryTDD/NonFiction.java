package com.qa.libraryTDD;

public class NonFiction extends Books{

	public NonFiction(String name) {
		super(name);

	}

}
