package com.qa.libraryTDD;

public interface Rent {
	public void checkIn();
	
	public void checkOut();
}
