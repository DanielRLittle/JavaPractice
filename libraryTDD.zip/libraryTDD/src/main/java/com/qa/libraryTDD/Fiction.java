package com.qa.libraryTDD;

public class Fiction extends Books{

	public Fiction(String name) {
		super(name);
	}

}
