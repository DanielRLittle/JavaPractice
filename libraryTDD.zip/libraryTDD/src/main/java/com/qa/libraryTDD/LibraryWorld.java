package com.qa.libraryTDD;

public class LibraryWorld {

	public static void main(String[] args) {
		Member m = new Member("Danny", "Little");
		Member m2 = new Member("Hugo", "Harding");
		System.out.println(m2.getID());

	}

}
