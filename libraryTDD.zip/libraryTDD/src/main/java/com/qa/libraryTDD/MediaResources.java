package com.qa.libraryTDD;

public class MediaResources implements Rent{

	public void checkIn() {
		
	}

	public void checkOut() {
		
	}

}
