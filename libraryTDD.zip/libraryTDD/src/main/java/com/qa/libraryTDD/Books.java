package com.qa.libraryTDD;

public class Books implements Rent{
	private String name;
	
	public Books(String name) {
		
	}
	

	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public void checkIn() {
		
	}
	
	public void checkInBook(Books book) {
		
	}

	public void checkOut() {
		
	}
	
	public void checkOutBook(Books book) {
		
	}
	
	public String checkRecords(Books book) {
		return name;
		
	}

}
